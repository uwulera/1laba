using System.Data;
using System.Security.Cryptography.X509Certificates;
using System.Windows.Forms;

namespace _1zadanie2ver
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }





        private void randomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.RowCount = 5; //��������� ���������� �����

            dataGridView1.ColumnCount = 5; //��������� ���������� ��������

            int n = 5;
            int m = 5;
            int[] sum = new int[n]; string t = ""; int SumMin = 0;
            Random r = new Random();
            int[] min = new int[n];
            int[,] M = new int[n, m];
            for (int i = 0; i < n; i++)
            {
                min[i] = 100;
                for (int j = 0; j < m; j++)
                {

                    M[i, j] = r.Next(-1000, 1000);
                    min[i] = Math.Min(min[i], M[i, j]);
                    sum[i] = sum[i] + M[i, j];
                    //t = t + "\t" + Convert.ToString(M[i, j]);
                    dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(M[i, j]);
                }

            }
            int Min = 100;
            for (int i = 0; i < n; i++)
            {
                Min = Math.Min(Min, sum[i]);
                SumMin = SumMin + min[i];
            }
            textBox1.Text = Convert.ToString(Min);
        }

        private void klavToolStripMenuItem_Click(object sender, EventArgs e)
        {

            int n = 5;
            int m = 5;
            dataGridView1.RowCount = n; //��������� ���������� �����

            dataGridView1.ColumnCount = m; //��������� ���������� ��������

        }
        private void button1_Click(object sender, EventArgs e)
        {
            min();
        }

        private void min()
        {
        }
    }
    }
